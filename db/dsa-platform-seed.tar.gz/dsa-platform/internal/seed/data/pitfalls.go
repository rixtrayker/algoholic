package data

import "dsa-platform/pkg/models"

// SeedPitfalls returns common mistakes linked to specific topics.
func SeedPitfalls() []models.Pitfall {
	return []models.Pitfall{
		// Two Pointers
		{TopicID: "two_pointers", Description: "Off-by-one in pointer initialization: using right=n instead of right=n-1", Example: "right := len(nums) causes index out of range on first access", Fix: "Always use right := len(nums)-1 for array bounds", Severity: 4},
		{TopicID: "two_pointers", Description: "Not skipping duplicates in 3Sum causing duplicate triplets", Example: "[-1,-1,0,1] produces [-1,0,1] twice", Fix: "After finding a match, skip while nums[lo]==nums[lo+1] and nums[hi]==nums[hi-1]", Severity: 4},
		{TopicID: "two_pointers", Description: "Infinite loop when neither pointer moves", Example: "while lo < hi with condition that never triggers lo++ or hi--", Fix: "Ensure every path in the loop body moves at least one pointer", Severity: 5},

		// Sliding Window
		{TopicID: "sliding_window", Description: "Forgetting to shrink the window — only expanding", Example: "Variable window never contracts, grows to full array size", Fix: "Always have a while/for loop that shrinks left when condition violated", Severity: 5},
		{TopicID: "sliding_window", Description: "Using wrong variable for answer tracking (window size vs value)", Example: "Tracking max sum but returning window length, or vice versa", Fix: "Be explicit: track both windowLen and windowSum if needed", Severity: 3},

		// Binary Search
		{TopicID: "binary_search", Description: "Using lo < hi vs lo <= hi incorrectly", Example: "lo < hi misses the case where lo == hi is the answer", Fix: "Use lo <= hi when search space includes a single element; lo < hi for partitioning variants", Severity: 5},
		{TopicID: "binary_search", Description: "Integer overflow in mid = (lo + hi) / 2", Example: "lo=1.5B, hi=2B → sum overflows int32", Fix: "Use mid = lo + (hi - lo) / 2", Severity: 4},
		{TopicID: "binary_search", Description: "Wrong half elimination in rotated array search", Example: "Not correctly identifying which half is sorted before comparing with target", Fix: "First check if left half is sorted (nums[lo]<=nums[mid]), then check target range", Severity: 4},

		// DP
		{TopicID: "dp_fundamentals", Description: "Wrong base case initialization", Example: "dp[0]=0 when it should be dp[0]=1 for counting problems", Fix: "Think carefully: what is the answer for the smallest valid input?", Severity: 5},
		{TopicID: "dp_fundamentals", Description: "Confusing top-down and bottom-up iteration order", Example: "Filling dp left-to-right when subproblems need right-to-left values", Fix: "Draw dependency arrows: ensure dp[i] only depends on already-computed cells", Severity: 4},
		{TopicID: "dp_knapsack", Description: "Using 1D array for 0/1 knapsack but iterating capacity left-to-right", Example: "dp[w] = max(dp[w], dp[w-weight]+val) counts items multiple times", Fix: "For 0/1 knapsack, iterate capacity RIGHT to LEFT. For unbounded, iterate LEFT to RIGHT.", Severity: 5},

		// BFS
		{TopicID: "graph_bfs", Description: "Marking visited after dequeueing instead of before enqueueing", Example: "Same node added to queue multiple times, causing TLE or wrong answer", Fix: "Mark visited[neighbor]=true BEFORE appending to queue", Severity: 5},
		{TopicID: "graph_bfs", Description: "Not marking the starting node as visited", Example: "Start node gets re-added to queue from its own neighbors", Fix: "Set visited[start]=true before the main loop", Severity: 4},

		// DFS
		{TopicID: "graph_dfs", Description: "Not handling disconnected components", Example: "DFS from node 0 misses nodes not reachable from 0", Fix: "Loop through all nodes and start DFS for each unvisited node", Severity: 3},

		// Monotonic Stack
		{TopicID: "monotonic_stack", Description: "Confusion about when to use increasing vs decreasing stack", Example: "Using decreasing stack for 'next greater element' gets wrong results", Fix: "For next GREATER → decreasing stack (pop when current > top). For next SMALLER → increasing stack.", Severity: 4},

		// Hash Map
		{TopicID: "hash_map", Description: "Two Sum: checking map before inserting leads to using same element twice", Example: "nums=[3,3], target=6: must find two different indices", Fix: "Check complement BEFORE adding current element to map, OR check that indices differ", Severity: 3},

		// Backtracking
		{TopicID: "backtracking", Description: "Forgetting to undo state changes (backtrack step)", Example: "path = append(path, x) without path = path[:len(path)-1] after recursive call", Fix: "Every state mutation before recursion needs a corresponding undo after", Severity: 5},
		{TopicID: "backtracking", Description: "Generating duplicates when input has repeated elements", Example: "nums=[1,1,2] generates [1,2] twice in subsets", Fix: "Sort input, then skip nums[i]==nums[i-1] when i>start", Severity: 4},
	}
}
