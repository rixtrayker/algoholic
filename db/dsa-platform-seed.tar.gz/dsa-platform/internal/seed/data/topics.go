package data

import "dsa-platform/pkg/models"

func ptr(s string) *string { return &s }

// SeedTopics returns the full hierarchical topic tree.
// Topics reference categories by slug (resolved at insert time to category_id).
func SeedTopics() []models.Topic {
	return []models.Topic{

		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
		// CATEGORY: Arrays & Strings
		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

		// -- Level 1: Top topics --
		{TopicID: "arrays_basics", Name: "Arrays Basics", Slug: "arrays-basics", Level: models.LevelTopic, Description: "Fundamentals of array manipulation, traversal, and in-place operations", Keywords: []string{"array", "traversal", "in-place", "swap"}, DifficultyMin: 0, DifficultyMax: 25, DisplayOrder: 1,
			Metadata: models.JSONB{"category_slug": "arrays_strings"}},

		{TopicID: "two_pointers", Name: "Two Pointers", Slug: "two-pointers", Level: models.LevelTopic, ParentTopicID: ptr("arrays_basics"), Description: "Technique using two pointers moving through array/string simultaneously", Keywords: []string{"two pointers", "opposite direction", "same direction", "fast slow"}, DifficultyMin: 10, DifficultyMax: 60, DisplayOrder: 2,
			Metadata: models.JSONB{"category_slug": "arrays_strings"}},

		{TopicID: "sliding_window", Name: "Sliding Window", Slug: "sliding-window", Level: models.LevelTopic, ParentTopicID: ptr("arrays_basics"), Description: "Maintain a window over a contiguous subarray/substring", Keywords: []string{"sliding window", "variable window", "fixed window", "substring"}, DifficultyMin: 15, DifficultyMax: 70, DisplayOrder: 3,
			Metadata: models.JSONB{"category_slug": "arrays_strings"}},

		{TopicID: "prefix_sum", Name: "Prefix Sum", Slug: "prefix-sum", Level: models.LevelTopic, ParentTopicID: ptr("arrays_basics"), Description: "Precomputed cumulative sums for O(1) range queries", Keywords: []string{"prefix sum", "cumulative", "range query", "subarray sum"}, DifficultyMin: 10, DifficultyMax: 55, DisplayOrder: 4,
			Metadata: models.JSONB{"category_slug": "arrays_strings"}},

		{TopicID: "strings", Name: "String Manipulation", Slug: "strings", Level: models.LevelTopic, Description: "String-specific operations, palindromes, anagrams, encoding", Keywords: []string{"string", "palindrome", "anagram", "substring", "encoding"}, DifficultyMin: 5, DifficultyMax: 65, DisplayOrder: 5,
			Metadata: models.JSONB{"category_slug": "arrays_strings"}},

		{TopicID: "intervals", Name: "Intervals", Slug: "intervals", Level: models.LevelTopic, Description: "Merge, insert, and manage overlapping intervals", Keywords: []string{"interval", "merge", "overlap", "sweep line"}, DifficultyMin: 20, DifficultyMax: 65, DisplayOrder: 6,
			Metadata: models.JSONB{"category_slug": "arrays_strings"}},

		// -- Level 2: Subtopics / Patterns --
		{TopicID: "two_ptr_opposite", Name: "Opposite Direction Pointers", Slug: "two-ptr-opposite", Level: models.LevelPattern, ParentTopicID: ptr("two_pointers"), Description: "Pointers start at opposite ends, converge toward center", Keywords: []string{"opposite", "converge", "pair sum"}, DifficultyMin: 10, DifficultyMax: 45, DisplayOrder: 1,
			Metadata: models.JSONB{"category_slug": "arrays_strings"}},

		{TopicID: "two_ptr_same_dir", Name: "Same Direction (Slow/Fast)", Slug: "two-ptr-same-dir", Level: models.LevelPattern, ParentTopicID: ptr("two_pointers"), Description: "Both pointers move forward at different speeds for in-place operations", Keywords: []string{"slow fast", "remove duplicates", "partition"}, DifficultyMin: 10, DifficultyMax: 40, DisplayOrder: 2,
			Metadata: models.JSONB{"category_slug": "arrays_strings"}},

		{TopicID: "two_ptr_cycle", Name: "Cycle Detection (Floyd)", Slug: "two-ptr-cycle", Level: models.LevelPattern, ParentTopicID: ptr("two_pointers"), Description: "Fast pointer moves 2x, slow 1x for cycle detection", Keywords: []string{"floyd", "cycle", "tortoise hare"}, DifficultyMin: 20, DifficultyMax: 55, DisplayOrder: 3,
			Metadata: models.JSONB{"category_slug": "arrays_strings"}},

		{TopicID: "sw_fixed", Name: "Fixed-Size Window", Slug: "sw-fixed", Level: models.LevelPattern, ParentTopicID: ptr("sliding_window"), Description: "Window of exactly k elements", Keywords: []string{"fixed window", "k elements"}, DifficultyMin: 15, DifficultyMax: 40, DisplayOrder: 1,
			Metadata: models.JSONB{"category_slug": "arrays_strings"}},

		{TopicID: "sw_variable", Name: "Variable-Size Window", Slug: "sw-variable", Level: models.LevelPattern, ParentTopicID: ptr("sliding_window"), Description: "Window expands and contracts based on validity condition", Keywords: []string{"variable window", "longest", "shortest", "at most k"}, DifficultyMin: 25, DifficultyMax: 70, DisplayOrder: 2,
			Metadata: models.JSONB{"category_slug": "arrays_strings"}},

		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
		// CATEGORY: Dynamic Programming
		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

		{TopicID: "dp_fundamentals", Name: "DP Fundamentals", Slug: "dp-fundamentals", Level: models.LevelTopic, Description: "Core DP concepts: overlapping subproblems, optimal substructure, memoization vs tabulation", Keywords: []string{"dp", "memoization", "tabulation", "subproblem"}, DifficultyMin: 15, DifficultyMax: 40, DisplayOrder: 1,
			Metadata: models.JSONB{"category_slug": "dynamic_programming"}},

		{TopicID: "dp_1d", Name: "1D DP (Linear)", Slug: "dp-1d", Level: models.LevelTopic, ParentTopicID: ptr("dp_fundamentals"), Description: "DP with single-dimensional state array", Keywords: []string{"1d dp", "fibonacci", "house robber", "climbing stairs"}, DifficultyMin: 15, DifficultyMax: 55, DisplayOrder: 2,
			Metadata: models.JSONB{"category_slug": "dynamic_programming"}},

		{TopicID: "dp_2d", Name: "2D DP (Grid/Two Sequences)", Slug: "dp-2d", Level: models.LevelTopic, ParentTopicID: ptr("dp_fundamentals"), Description: "DP with two-dimensional state: grids, LCS, edit distance", Keywords: []string{"2d dp", "grid", "lcs", "edit distance"}, DifficultyMin: 30, DifficultyMax: 70, DisplayOrder: 3,
			Metadata: models.JSONB{"category_slug": "dynamic_programming"}},

		{TopicID: "dp_knapsack", Name: "Knapsack Patterns", Slug: "dp-knapsack", Level: models.LevelTopic, ParentTopicID: ptr("dp_fundamentals"), Description: "0/1 knapsack, unbounded, subset sum, coin change", Keywords: []string{"knapsack", "subset sum", "coin change", "0/1"}, DifficultyMin: 30, DifficultyMax: 75, DisplayOrder: 4,
			Metadata: models.JSONB{"category_slug": "dynamic_programming"}},

		{TopicID: "dp_lis", Name: "Longest Increasing Subsequence", Slug: "dp-lis", Level: models.LevelTopic, ParentTopicID: ptr("dp_fundamentals"), Description: "LIS and its variations with O(n²) and O(n log n) approaches", Keywords: []string{"lis", "longest increasing", "patience sorting"}, DifficultyMin: 35, DifficultyMax: 70, DisplayOrder: 5,
			Metadata: models.JSONB{"category_slug": "dynamic_programming"}},

		{TopicID: "dp_interval", Name: "Interval DP", Slug: "dp-interval", Level: models.LevelTopic, ParentTopicID: ptr("dp_fundamentals"), Description: "DP over contiguous intervals: matrix chain, burst balloons", Keywords: []string{"interval dp", "matrix chain", "palindrome partition"}, DifficultyMin: 50, DifficultyMax: 85, DisplayOrder: 6,
			Metadata: models.JSONB{"category_slug": "dynamic_programming"}},

		{TopicID: "dp_tree", Name: "Tree DP", Slug: "dp-tree", Level: models.LevelTopic, ParentTopicID: ptr("dp_fundamentals"), Description: "DP on tree structures with post-order traversal", Keywords: []string{"tree dp", "rerooting", "subtree"}, DifficultyMin: 45, DifficultyMax: 85, DisplayOrder: 7,
			Metadata: models.JSONB{"category_slug": "dynamic_programming"}},

		{TopicID: "dp_bitmask", Name: "Bitmask DP", Slug: "dp-bitmask", Level: models.LevelTopic, ParentTopicID: ptr("dp_fundamentals"), Description: "DP with bitmask state for subset enumeration", Keywords: []string{"bitmask dp", "tsp", "subset"}, DifficultyMin: 55, DifficultyMax: 95, DisplayOrder: 8,
			Metadata: models.JSONB{"category_slug": "dynamic_programming"}},

		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
		// CATEGORY: Graphs & Trees
		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

		{TopicID: "graph_representation", Name: "Graph Representation", Slug: "graph-representation", Level: models.LevelTopic, Description: "Adjacency list, matrix, edge list, when to use which", Keywords: []string{"adjacency list", "adjacency matrix", "edge list"}, DifficultyMin: 5, DifficultyMax: 20, DisplayOrder: 1,
			Metadata: models.JSONB{"category_slug": "graphs_trees"}},

		{TopicID: "graph_bfs", Name: "BFS (Breadth-First Search)", Slug: "bfs", Level: models.LevelTopic, ParentTopicID: ptr("graph_representation"), Description: "Level-order traversal using queue, shortest path in unweighted graphs", Keywords: []string{"bfs", "breadth first", "queue", "shortest path", "level order"}, DifficultyMin: 15, DifficultyMax: 65, DisplayOrder: 2,
			Metadata: models.JSONB{"category_slug": "graphs_trees"}},

		{TopicID: "graph_dfs", Name: "DFS (Depth-First Search)", Slug: "dfs", Level: models.LevelTopic, ParentTopicID: ptr("graph_representation"), Description: "Recursive/iterative deep traversal, connected components, cycle detection", Keywords: []string{"dfs", "depth first", "recursion", "backtrack", "connected components"}, DifficultyMin: 15, DifficultyMax: 70, DisplayOrder: 3,
			Metadata: models.JSONB{"category_slug": "graphs_trees"}},

		{TopicID: "topological_sort", Name: "Topological Sort", Slug: "topological-sort", Level: models.LevelTopic, ParentTopicID: ptr("graph_representation"), Description: "Linear ordering of DAG vertices respecting edge directions (Kahn's / DFS)", Keywords: []string{"topological", "dag", "kahn", "course schedule"}, DifficultyMin: 30, DifficultyMax: 60, DisplayOrder: 4,
			Metadata: models.JSONB{"category_slug": "graphs_trees"}},

		{TopicID: "shortest_path", Name: "Shortest Path Algorithms", Slug: "shortest-path", Level: models.LevelTopic, ParentTopicID: ptr("graph_representation"), Description: "Dijkstra, Bellman-Ford, Floyd-Warshall for weighted graphs", Keywords: []string{"dijkstra", "bellman-ford", "shortest path", "weighted graph"}, DifficultyMin: 35, DifficultyMax: 80, DisplayOrder: 5,
			Metadata: models.JSONB{"category_slug": "graphs_trees"}},

		{TopicID: "union_find", Name: "Union-Find (Disjoint Set)", Slug: "union-find", Level: models.LevelTopic, ParentTopicID: ptr("graph_representation"), Description: "Disjoint set union with path compression and union by rank", Keywords: []string{"union find", "disjoint set", "connected components", "path compression"}, DifficultyMin: 25, DifficultyMax: 65, DisplayOrder: 6,
			Metadata: models.JSONB{"category_slug": "graphs_trees"}},

		{TopicID: "mst", Name: "Minimum Spanning Tree", Slug: "mst", Level: models.LevelTopic, ParentTopicID: ptr("graph_representation"), Description: "Kruskal's and Prim's algorithms for MST", Keywords: []string{"mst", "kruskal", "prim", "spanning tree"}, DifficultyMin: 35, DifficultyMax: 65, DisplayOrder: 7,
			Metadata: models.JSONB{"category_slug": "graphs_trees"}},

		{TopicID: "binary_tree", Name: "Binary Trees", Slug: "binary-tree", Level: models.LevelTopic, Description: "Binary tree traversals, construction, properties", Keywords: []string{"binary tree", "inorder", "preorder", "postorder", "level order"}, DifficultyMin: 10, DifficultyMax: 55, DisplayOrder: 8,
			Metadata: models.JSONB{"category_slug": "graphs_trees"}},

		{TopicID: "bst", Name: "Binary Search Trees", Slug: "bst", Level: models.LevelTopic, ParentTopicID: ptr("binary_tree"), Description: "BST operations, validation, balancing, iterators", Keywords: []string{"bst", "search tree", "inorder sorted", "validate"}, DifficultyMin: 15, DifficultyMax: 60, DisplayOrder: 9,
			Metadata: models.JSONB{"category_slug": "graphs_trees"}},

		{TopicID: "lca", Name: "Lowest Common Ancestor", Slug: "lca", Level: models.LevelTopic, ParentTopicID: ptr("binary_tree"), Description: "Finding LCA in binary trees and BSTs", Keywords: []string{"lca", "ancestor", "path"}, DifficultyMin: 25, DifficultyMax: 60, DisplayOrder: 10,
			Metadata: models.JSONB{"category_slug": "graphs_trees"}},

		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
		// CATEGORY: Sorting & Searching
		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

		{TopicID: "sorting_basics", Name: "Sorting Algorithms", Slug: "sorting-algorithms", Level: models.LevelTopic, Description: "Comparison and non-comparison sorts", Keywords: []string{"sort", "quicksort", "mergesort", "heapsort"}, DifficultyMin: 10, DifficultyMax: 50, DisplayOrder: 1,
			Metadata: models.JSONB{"category_slug": "sorting_searching"}},

		{TopicID: "binary_search", Name: "Binary Search", Slug: "binary-search", Level: models.LevelTopic, Description: "Classic binary search and its many variations", Keywords: []string{"binary search", "bisect", "lower bound", "upper bound"}, DifficultyMin: 15, DifficultyMax: 65, DisplayOrder: 2,
			Metadata: models.JSONB{"category_slug": "sorting_searching"}},

		{TopicID: "bs_on_answer", Name: "Binary Search on Answer", Slug: "bs-on-answer", Level: models.LevelPattern, ParentTopicID: ptr("binary_search"), Description: "Binary search on the result space when checking feasibility is easier", Keywords: []string{"search on answer", "minimize maximum", "feasibility check"}, DifficultyMin: 35, DifficultyMax: 75, DisplayOrder: 3,
			Metadata: models.JSONB{"category_slug": "sorting_searching"}},

		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
		// CATEGORY: Stacks & Queues
		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

		{TopicID: "stack", Name: "Stack", Slug: "stack", Level: models.LevelTopic, Description: "LIFO data structure: parentheses matching, expression evaluation", Keywords: []string{"stack", "lifo", "parentheses", "expression"}, DifficultyMin: 5, DifficultyMax: 40, DisplayOrder: 1,
			Metadata: models.JSONB{"category_slug": "stacks_queues"}},

		{TopicID: "monotonic_stack", Name: "Monotonic Stack", Slug: "monotonic-stack", Level: models.LevelTopic, ParentTopicID: ptr("stack"), Description: "Stack maintaining monotonic order for next greater/smaller element", Keywords: []string{"monotonic stack", "next greater", "next smaller", "histogram"}, DifficultyMin: 25, DifficultyMax: 70, DisplayOrder: 2,
			Metadata: models.JSONB{"category_slug": "stacks_queues"}},

		{TopicID: "queue", Name: "Queue", Slug: "queue", Level: models.LevelTopic, Description: "FIFO data structure and BFS foundation", Keywords: []string{"queue", "fifo", "bfs"}, DifficultyMin: 5, DifficultyMax: 30, DisplayOrder: 3,
			Metadata: models.JSONB{"category_slug": "stacks_queues"}},

		{TopicID: "priority_queue", Name: "Priority Queue / Heap", Slug: "priority-queue", Level: models.LevelTopic, Description: "Heap-based priority queue for top-k, merge-k, scheduling", Keywords: []string{"heap", "priority queue", "top k", "kth largest"}, DifficultyMin: 20, DifficultyMax: 65, DisplayOrder: 4,
			Metadata: models.JSONB{"category_slug": "stacks_queues"}},

		{TopicID: "monotonic_queue", Name: "Monotonic Queue / Deque", Slug: "monotonic-queue", Level: models.LevelTopic, ParentTopicID: ptr("queue"), Description: "Deque maintaining monotonic order for sliding window min/max", Keywords: []string{"monotonic queue", "deque", "sliding window max"}, DifficultyMin: 35, DifficultyMax: 70, DisplayOrder: 5,
			Metadata: models.JSONB{"category_slug": "stacks_queues"}},

		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
		// CATEGORY: Hash Tables
		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

		{TopicID: "hash_map", Name: "Hash Map", Slug: "hash-map", Level: models.LevelTopic, Description: "Key-value store, O(1) lookup, two-sum pattern", Keywords: []string{"hash map", "dictionary", "key value"}, DifficultyMin: 5, DifficultyMax: 45, DisplayOrder: 1,
			Metadata: models.JSONB{"category_slug": "hash_tables"}},

		{TopicID: "hash_set", Name: "Hash Set", Slug: "hash-set", Level: models.LevelTopic, Description: "Unique element tracking, membership checking", Keywords: []string{"hash set", "unique", "membership"}, DifficultyMin: 5, DifficultyMax: 30, DisplayOrder: 2,
			Metadata: models.JSONB{"category_slug": "hash_tables"}},

		{TopicID: "frequency_counting", Name: "Frequency Counting", Slug: "frequency-counting", Level: models.LevelPattern, ParentTopicID: ptr("hash_map"), Description: "Counting occurrences, anagram detection, majority element", Keywords: []string{"frequency", "count", "anagram", "majority"}, DifficultyMin: 10, DifficultyMax: 45, DisplayOrder: 3,
			Metadata: models.JSONB{"category_slug": "hash_tables"}},

		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
		// CATEGORY: Greedy & Backtracking
		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

		{TopicID: "greedy", Name: "Greedy Algorithms", Slug: "greedy", Level: models.LevelTopic, Description: "Locally optimal choices leading to global optimum", Keywords: []string{"greedy", "locally optimal", "scheduling"}, DifficultyMin: 15, DifficultyMax: 65, DisplayOrder: 1,
			Metadata: models.JSONB{"category_slug": "greedy_backtracking"}},

		{TopicID: "backtracking", Name: "Backtracking", Slug: "backtracking", Level: models.LevelTopic, Description: "Exhaustive search with pruning: subsets, permutations, constraint satisfaction", Keywords: []string{"backtracking", "recursion", "permutation", "subset", "pruning"}, DifficultyMin: 25, DifficultyMax: 75, DisplayOrder: 2,
			Metadata: models.JSONB{"category_slug": "greedy_backtracking"}},

		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
		// CATEGORY: Advanced Data Structures
		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

		{TopicID: "trie", Name: "Trie (Prefix Tree)", Slug: "trie", Level: models.LevelTopic, Description: "Prefix-based string search tree", Keywords: []string{"trie", "prefix tree", "autocomplete"}, DifficultyMin: 25, DifficultyMax: 60, DisplayOrder: 1,
			Metadata: models.JSONB{"category_slug": "advanced_ds"}},

		{TopicID: "segment_tree", Name: "Segment Tree", Slug: "segment-tree", Level: models.LevelTopic, Description: "Range query and point/range update in O(log n)", Keywords: []string{"segment tree", "range query", "lazy propagation"}, DifficultyMin: 50, DifficultyMax: 90, DisplayOrder: 2,
			Metadata: models.JSONB{"category_slug": "advanced_ds"}},

		{TopicID: "fenwick_tree", Name: "Fenwick Tree (BIT)", Slug: "fenwick-tree", Level: models.LevelTopic, Description: "Binary indexed tree for prefix sum updates", Keywords: []string{"fenwick", "bit", "binary indexed tree"}, DifficultyMin: 45, DifficultyMax: 80, DisplayOrder: 3,
			Metadata: models.JSONB{"category_slug": "advanced_ds"}},

		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
		// CATEGORY: Bit Manipulation
		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

		{TopicID: "bit_basics", Name: "Bitwise Operations", Slug: "bitwise-ops", Level: models.LevelTopic, Description: "AND, OR, XOR, NOT, shifts and common bit tricks", Keywords: []string{"bitwise", "xor", "and", "or", "shift"}, DifficultyMin: 10, DifficultyMax: 50, DisplayOrder: 1,
			Metadata: models.JSONB{"category_slug": "bit_manipulation"}},

		{TopicID: "bit_tricks", Name: "Bit Tricks & Hacks", Slug: "bit-tricks", Level: models.LevelPattern, ParentTopicID: ptr("bit_basics"), Description: "Power-of-two check, counting set bits, isolating bits", Keywords: []string{"popcount", "power of two", "brian kernighan"}, DifficultyMin: 15, DifficultyMax: 55, DisplayOrder: 2,
			Metadata: models.JSONB{"category_slug": "bit_manipulation"}},
	}
}
