package data

import "dsa-platform/pkg/models"

func intPtr(n int) *int { return &n }

// SeedProblems returns a curated set of foundational LeetCode problems.
func SeedProblems() []models.Problem {
	return []models.Problem{

		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
		// ARRAYS & TWO POINTERS
		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

		{
			LeetcodeNumber: intPtr(1), Slug: "two-sum", Title: "Two Sum",
			Statement:     "Given an array of integers nums and an integer target, return indices of the two numbers such that they add up to target.",
			Constraints:   []string{"2 <= nums.length <= 10^4", "-10^9 <= nums[i] <= 10^9", "-10^9 <= target <= 10^9", "Only one valid answer exists."},
			Examples:      []models.ProblemExample{{Input: "nums = [2,7,11,15], target = 9", Output: "[0,1]", Explanation: "nums[0] + nums[1] == 9"}},
			Hints:         []string{"A hash map can reduce lookup time.", "For each element, check if target - element exists in the map."},
			DifficultyScore: 15, DifficultyLabel: "easy", PrimaryPattern: "hashing", TimeComplexity: "O(n)", SpaceComplexity: "O(n)",
			Frequency: 0.95, Companies: []string{"Google", "Amazon", "Meta", "Microsoft", "Apple"},
			TopicLinks: []models.ProblemTopicLink{
				{TopicID: "hash_map", Relevance: 1.0, IsPrimary: true, PatternUsed: "complement lookup", KeyInsight: "Store seen values, check complement existence"},
				{TopicID: "arrays_basics", Relevance: 0.7, IsPrimary: false},
			},
			TagSlugs: []string{"array", "hash-table", "hashing", "google", "meta", "amazon"},
		},

		{
			LeetcodeNumber: intPtr(167), Slug: "two-sum-ii", Title: "Two Sum II - Input Array Is Sorted",
			Statement:     "Given a 1-indexed sorted array, find two numbers that add up to a specific target.",
			Constraints:   []string{"2 <= numbers.length <= 3 * 10^4", "-1000 <= numbers[i] <= 1000", "numbers is sorted in non-decreasing order"},
			Examples:      []models.ProblemExample{{Input: "numbers = [2,7,11,15], target = 9", Output: "[1,2]"}},
			Hints:         []string{"The array is sorted — can you exploit that?", "Two pointers from opposite ends."},
			DifficultyScore: 20, DifficultyLabel: "medium", PrimaryPattern: "two_pointers_opposite", TimeComplexity: "O(n)", SpaceComplexity: "O(1)",
			Frequency: 0.7, Companies: []string{"Amazon", "Bloomberg"},
			TopicLinks: []models.ProblemTopicLink{
				{TopicID: "two_pointers", Relevance: 1.0, IsPrimary: true, PatternUsed: "opposite direction", KeyInsight: "Sorted array → opposite pointers, adjust based on sum vs target"},
				{TopicID: "two_ptr_opposite", Relevance: 1.0, IsPrimary: false},
			},
			TagSlugs: []string{"array", "two-pointers", "amazon"},
		},

		{
			LeetcodeNumber: intPtr(15), Slug: "3sum", Title: "3Sum",
			Statement:     "Given an integer array nums, return all the triplets [nums[i], nums[j], nums[k]] such that i != j, i != k, and j != k, and nums[i] + nums[j] + nums[k] == 0.",
			Constraints:   []string{"3 <= nums.length <= 3000", "-10^5 <= nums[i] <= 10^5"},
			Examples:      []models.ProblemExample{{Input: "nums = [-1,0,1,2,-1,-4]", Output: "[[-1,-1,2],[-1,0,1]]"}},
			Hints:         []string{"Sort first, then fix one element and use two pointers for the rest.", "Skip duplicates carefully."},
			DifficultyScore: 38, DifficultyLabel: "medium", PrimaryPattern: "two_pointers_opposite", TimeComplexity: "O(n²)", SpaceComplexity: "O(1)",
			Frequency: 0.9, Companies: []string{"Meta", "Google", "Amazon", "Microsoft"},
			TopicLinks: []models.ProblemTopicLink{
				{TopicID: "two_pointers", Relevance: 1.0, IsPrimary: true, PatternUsed: "sort + fix one + opposite pointers", KeyInsight: "Reduce to 2Sum with sorted array, handle duplicates"},
				{TopicID: "sorting_basics", Relevance: 0.5, IsPrimary: false},
			},
			TagSlugs: []string{"array", "two-pointers", "sorting", "edge-case-heavy", "meta", "google"},
		},

		{
			LeetcodeNumber: intPtr(11), Slug: "container-with-most-water", Title: "Container With Most Water",
			Statement:     "Given n non-negative integers representing heights, find two lines that together with the x-axis forms a container that holds the most water.",
			Constraints:   []string{"n == height.length", "2 <= n <= 10^5", "0 <= height[i] <= 10^4"},
			Examples:      []models.ProblemExample{{Input: "height = [1,8,6,2,5,4,8,3,7]", Output: "49"}},
			Hints:         []string{"Start with widest container.", "Move the shorter pointer inward — why?"},
			DifficultyScore: 30, DifficultyLabel: "medium", PrimaryPattern: "two_pointers_opposite", TimeComplexity: "O(n)", SpaceComplexity: "O(1)",
			Frequency: 0.8, Companies: []string{"Google", "Amazon"},
			TopicLinks: []models.ProblemTopicLink{
				{TopicID: "two_pointers", Relevance: 1.0, IsPrimary: true, PatternUsed: "opposite direction greedy shrink", KeyInsight: "Moving shorter pointer can only potentially increase area"},
			},
			TagSlugs: []string{"array", "two-pointers", "greedy", "requires-proof", "google"},
		},

		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
		// SLIDING WINDOW
		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

		{
			LeetcodeNumber: intPtr(3), Slug: "longest-substring-without-repeating", Title: "Longest Substring Without Repeating Characters",
			Statement:     "Given a string s, find the length of the longest substring without repeating characters.",
			Constraints:   []string{"0 <= s.length <= 5 * 10^4", "s consists of English letters, digits, symbols and spaces"},
			Examples:      []models.ProblemExample{{Input: `s = "abcabcbb"`, Output: "3", Explanation: `The answer is "abc"`}},
			DifficultyScore: 28, DifficultyLabel: "medium", PrimaryPattern: "sliding_window_variable", TimeComplexity: "O(n)", SpaceComplexity: "O(min(m,n))",
			Frequency: 0.92, Companies: []string{"Amazon", "Google", "Meta", "Bloomberg"},
			TopicLinks: []models.ProblemTopicLink{
				{TopicID: "sliding_window", Relevance: 1.0, IsPrimary: true, PatternUsed: "variable window + hash set", KeyInsight: "Expand right, shrink left when duplicate found"},
				{TopicID: "sw_variable", Relevance: 1.0, IsPrimary: false},
				{TopicID: "hash_set", Relevance: 0.7, IsPrimary: false},
			},
			TagSlugs: []string{"string", "hash-table", "sliding-window", "amazon", "google", "meta"},
		},

		{
			LeetcodeNumber: intPtr(76), Slug: "minimum-window-substring", Title: "Minimum Window Substring",
			Statement:     "Given two strings s and t, return the minimum window substring of s such that every character in t (including duplicates) is included in the window.",
			Constraints:   []string{"1 <= s.length, t.length <= 10^5"},
			Examples:      []models.ProblemExample{{Input: `s = "ADOBECODEBANC", t = "ABC"`, Output: `"BANC"`}},
			DifficultyScore: 55, DifficultyLabel: "hard", PrimaryPattern: "sliding_window_variable", TimeComplexity: "O(|s| + |t|)", SpaceComplexity: "O(|s| + |t|)",
			Frequency: 0.78, Companies: []string{"Meta", "Google", "Uber"},
			TopicLinks: []models.ProblemTopicLink{
				{TopicID: "sliding_window", Relevance: 1.0, IsPrimary: true, PatternUsed: "variable window + frequency map", KeyInsight: "Track required vs window counts, shrink when all satisfied"},
				{TopicID: "sw_variable", Relevance: 1.0, IsPrimary: false},
				{TopicID: "frequency_counting", Relevance: 0.8, IsPrimary: false},
			},
			TagSlugs: []string{"string", "hash-table", "sliding-window", "edge-case-heavy", "meta"},
		},

		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
		// BINARY SEARCH
		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

		{
			LeetcodeNumber: intPtr(33), Slug: "search-in-rotated-sorted-array", Title: "Search in Rotated Sorted Array",
			Statement:     "Given a rotated sorted array and a target, return the index of target or -1.",
			Constraints:   []string{"1 <= nums.length <= 5000", "-10^4 <= nums[i] <= 10^4", "All values are unique", "nums is an ascending array that is possibly rotated"},
			Examples:      []models.ProblemExample{{Input: "nums = [4,5,6,7,0,1,2], target = 0", Output: "4"}},
			DifficultyScore: 40, DifficultyLabel: "medium", PrimaryPattern: "binary_search", TimeComplexity: "O(log n)", SpaceComplexity: "O(1)",
			Frequency: 0.85, Companies: []string{"Meta", "Google", "Amazon", "Microsoft"},
			TopicLinks: []models.ProblemTopicLink{
				{TopicID: "binary_search", Relevance: 1.0, IsPrimary: true, PatternUsed: "modified binary search", KeyInsight: "One half is always sorted — determine which and check if target is in that half"},
			},
			TagSlugs: []string{"array", "binary-search", "off-by-one", "meta", "google"},
		},

		{
			LeetcodeNumber: intPtr(875), Slug: "koko-eating-bananas", Title: "Koko Eating Bananas",
			Statement:     "Koko loves to eat bananas. Return the minimum integer eating speed k such that she can eat all bananas within h hours.",
			Constraints:   []string{"1 <= piles.length <= 10^4", "piles.length <= h <= 10^9", "1 <= piles[i] <= 10^9"},
			Examples:      []models.ProblemExample{{Input: "piles = [3,6,7,11], h = 8", Output: "4"}},
			DifficultyScore: 42, DifficultyLabel: "medium", PrimaryPattern: "binary_search_on_answer", TimeComplexity: "O(n log m)", SpaceComplexity: "O(1)",
			Frequency: 0.7, Companies: []string{"Google"},
			TopicLinks: []models.ProblemTopicLink{
				{TopicID: "bs_on_answer", Relevance: 1.0, IsPrimary: true, PatternUsed: "binary search on answer space", KeyInsight: "Search speed [1..max(piles)], feasibility check is O(n)"},
				{TopicID: "binary_search", Relevance: 0.8, IsPrimary: false},
			},
			TagSlugs: []string{"array", "binary-search", "google"},
		},

		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
		// DYNAMIC PROGRAMMING
		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

		{
			LeetcodeNumber: intPtr(70), Slug: "climbing-stairs", Title: "Climbing Stairs",
			Statement:     "You are climbing a staircase with n steps. Each time you can climb 1 or 2 steps. How many distinct ways can you reach the top?",
			Constraints:   []string{"1 <= n <= 45"},
			Examples:      []models.ProblemExample{{Input: "n = 3", Output: "3", Explanation: "1+1+1, 1+2, 2+1"}},
			DifficultyScore: 12, DifficultyLabel: "easy", PrimaryPattern: "dp_1d", TimeComplexity: "O(n)", SpaceComplexity: "O(1)",
			Frequency: 0.8, Companies: []string{"Amazon", "Google"},
			TopicLinks: []models.ProblemTopicLink{
				{TopicID: "dp_1d", Relevance: 1.0, IsPrimary: true, PatternUsed: "fibonacci-like recurrence", KeyInsight: "dp[i] = dp[i-1] + dp[i-2], same as Fibonacci"},
				{TopicID: "dp_fundamentals", Relevance: 0.8, IsPrimary: false},
			},
			TagSlugs: []string{"dp", "memoization", "space-optimization", "tricky-base-case"},
		},

		{
			LeetcodeNumber: intPtr(198), Slug: "house-robber", Title: "House Robber",
			Statement:     "Given an array representing money at each house, return max money you can rob without robbing two adjacent houses.",
			Constraints:   []string{"1 <= nums.length <= 100", "0 <= nums[i] <= 400"},
			Examples:      []models.ProblemExample{{Input: "nums = [1,2,3,1]", Output: "4", Explanation: "Rob house 1 (1) + house 3 (3) = 4"}},
			DifficultyScore: 22, DifficultyLabel: "medium", PrimaryPattern: "dp_1d", TimeComplexity: "O(n)", SpaceComplexity: "O(1)",
			Frequency: 0.82, Companies: []string{"Amazon", "Google", "Uber"},
			TopicLinks: []models.ProblemTopicLink{
				{TopicID: "dp_1d", Relevance: 1.0, IsPrimary: true, PatternUsed: "take-or-skip recurrence", KeyInsight: "dp[i] = max(dp[i-1], dp[i-2] + nums[i])"},
			},
			TagSlugs: []string{"array", "dp", "space-optimization"},
		},

		{
			LeetcodeNumber: intPtr(1143), Slug: "longest-common-subsequence", Title: "Longest Common Subsequence",
			Statement:     "Given two strings text1 and text2, return the length of their longest common subsequence.",
			Constraints:   []string{"1 <= text1.length, text2.length <= 1000", "text1 and text2 consist of only lowercase English characters"},
			Examples:      []models.ProblemExample{{Input: `text1 = "abcde", text2 = "ace"`, Output: "3"}},
			DifficultyScore: 38, DifficultyLabel: "medium", PrimaryPattern: "dp_2d", TimeComplexity: "O(m*n)", SpaceComplexity: "O(m*n)",
			Frequency: 0.75, Companies: []string{"Google", "Amazon"},
			TopicLinks: []models.ProblemTopicLink{
				{TopicID: "dp_2d", Relevance: 1.0, IsPrimary: true, PatternUsed: "two-sequence DP", KeyInsight: "Match → dp[i-1][j-1]+1, else max(dp[i-1][j], dp[i][j-1])"},
			},
			TagSlugs: []string{"string", "dp", "space-optimization", "google"},
		},

		{
			LeetcodeNumber: intPtr(322), Slug: "coin-change", Title: "Coin Change",
			Statement:     "Given coins of different denominations and a total amount, return fewest coins needed to make up that amount, or -1 if impossible.",
			Constraints:   []string{"1 <= coins.length <= 12", "1 <= coins[i] <= 2^31 - 1", "0 <= amount <= 10^4"},
			Examples:      []models.ProblemExample{{Input: "coins = [1,5,11], amount = 15", Output: "3", Explanation: "5+5+5"}},
			DifficultyScore: 32, DifficultyLabel: "medium", PrimaryPattern: "dp_knapsack_unbounded", TimeComplexity: "O(amount * n)", SpaceComplexity: "O(amount)",
			Frequency: 0.85, Companies: []string{"Amazon", "Google", "Bloomberg"},
			TopicLinks: []models.ProblemTopicLink{
				{TopicID: "dp_knapsack", Relevance: 1.0, IsPrimary: true, PatternUsed: "unbounded knapsack", KeyInsight: "dp[i] = min(dp[i-coin]+1) for each coin, init dp[0]=0 rest=INF"},
			},
			TagSlugs: []string{"array", "dp", "overflow-prone", "tricky-base-case"},
		},

		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
		// GRAPHS & TREES
		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

		{
			LeetcodeNumber: intPtr(200), Slug: "number-of-islands", Title: "Number of Islands",
			Statement:     "Given an m x n 2D grid map of '1's (land) and '0's (water), return the number of islands.",
			Constraints:   []string{"m == grid.length", "n == grid[i].length", "1 <= m, n <= 300", "grid[i][j] is '0' or '1'"},
			Examples:      []models.ProblemExample{{Input: `grid = [["1","1","0","0","0"],["1","1","0","0","0"],["0","0","1","0","0"],["0","0","0","1","1"]]`, Output: "3"}},
			DifficultyScore: 28, DifficultyLabel: "medium", PrimaryPattern: "dfs_grid", TimeComplexity: "O(m*n)", SpaceComplexity: "O(m*n)",
			Frequency: 0.9, Companies: []string{"Amazon", "Google", "Meta", "Microsoft"},
			TopicLinks: []models.ProblemTopicLink{
				{TopicID: "graph_dfs", Relevance: 1.0, IsPrimary: true, PatternUsed: "grid DFS flood fill", KeyInsight: "For each unvisited '1', DFS to mark entire island, increment count"},
				{TopicID: "graph_bfs", Relevance: 0.7, IsPrimary: false, PatternUsed: "BFS alternative"},
			},
			TagSlugs: []string{"matrix", "dfs", "bfs", "graph", "amazon", "google", "meta"},
		},

		{
			LeetcodeNumber: intPtr(207), Slug: "course-schedule", Title: "Course Schedule",
			Statement:     "There are numCourses courses labeled 0 to numCourses-1. Given prerequisites pairs, determine if you can finish all courses.",
			Constraints:   []string{"1 <= numCourses <= 2000", "0 <= prerequisites.length <= 5000"},
			Examples:      []models.ProblemExample{{Input: "numCourses = 2, prerequisites = [[1,0]]", Output: "true"}},
			DifficultyScore: 35, DifficultyLabel: "medium", PrimaryPattern: "topological_sort", TimeComplexity: "O(V+E)", SpaceComplexity: "O(V+E)",
			Frequency: 0.8, Companies: []string{"Amazon", "Google", "Meta"},
			TopicLinks: []models.ProblemTopicLink{
				{TopicID: "topological_sort", Relevance: 1.0, IsPrimary: true, PatternUsed: "Kahn's BFS / DFS cycle detection", KeyInsight: "Cycle in prerequisites → impossible, topological sort checks this"},
			},
			TagSlugs: []string{"graph", "topological-sort", "bfs", "dfs", "amazon", "google"},
		},

		{
			LeetcodeNumber: intPtr(226), Slug: "invert-binary-tree", Title: "Invert Binary Tree",
			Statement:     "Given the root of a binary tree, invert the tree, and return its root.",
			Constraints:   []string{"The number of nodes in the tree is in the range [0, 100]", "-100 <= Node.val <= 100"},
			Examples:      []models.ProblemExample{{Input: "root = [4,2,7,1,3,6,9]", Output: "[4,7,2,9,6,3,1]"}},
			DifficultyScore: 10, DifficultyLabel: "easy", PrimaryPattern: "tree_recursion", TimeComplexity: "O(n)", SpaceComplexity: "O(h)",
			Frequency: 0.7, Companies: []string{"Google"},
			TopicLinks: []models.ProblemTopicLink{
				{TopicID: "binary_tree", Relevance: 1.0, IsPrimary: true, PatternUsed: "recursive swap", KeyInsight: "Swap left and right children at every node recursively"},
			},
			TagSlugs: []string{"binary-tree", "recursion", "dfs", "google"},
		},

		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
		// STACK / MONOTONIC STACK
		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

		{
			LeetcodeNumber: intPtr(20), Slug: "valid-parentheses", Title: "Valid Parentheses",
			Statement:     "Given a string s containing just the characters '(', ')', '{', '}', '[' and ']', determine if the input string is valid.",
			Constraints:   []string{"1 <= s.length <= 10^4"},
			Examples:      []models.ProblemExample{{Input: `s = "()[]{}"`, Output: "true"}},
			DifficultyScore: 10, DifficultyLabel: "easy", PrimaryPattern: "stack", TimeComplexity: "O(n)", SpaceComplexity: "O(n)",
			Frequency: 0.88, Companies: []string{"Amazon", "Google", "Meta", "Bloomberg"},
			TopicLinks: []models.ProblemTopicLink{
				{TopicID: "stack", Relevance: 1.0, IsPrimary: true, PatternUsed: "matching parentheses", KeyInsight: "Push openers, pop and match closers, check empty at end"},
			},
			TagSlugs: []string{"string", "stack", "amazon", "meta"},
		},

		{
			LeetcodeNumber: intPtr(84), Slug: "largest-rectangle-in-histogram", Title: "Largest Rectangle in Histogram",
			Statement:     "Given an array of integers heights representing the histogram's bar height, find the area of the largest rectangle in the histogram.",
			Constraints:   []string{"1 <= heights.length <= 10^5", "0 <= heights[i] <= 10^4"},
			Examples:      []models.ProblemExample{{Input: "heights = [2,1,5,6,2,3]", Output: "10"}},
			DifficultyScore: 60, DifficultyLabel: "hard", PrimaryPattern: "monotonic_stack", TimeComplexity: "O(n)", SpaceComplexity: "O(n)",
			Frequency: 0.72, Companies: []string{"Google", "Amazon", "Microsoft"},
			TopicLinks: []models.ProblemTopicLink{
				{TopicID: "monotonic_stack", Relevance: 1.0, IsPrimary: true, PatternUsed: "increasing monotonic stack", KeyInsight: "When bar is shorter, pop and calculate area using stack top as height"},
			},
			TagSlugs: []string{"array", "stack", "monotonic-stack", "edge-case-heavy", "google"},
		},

		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
		// HEAP
		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

		{
			LeetcodeNumber: intPtr(215), Slug: "kth-largest-element", Title: "Kth Largest Element in an Array",
			Statement:     "Given an integer array nums and an integer k, return the kth largest element in the array.",
			Constraints:   []string{"1 <= k <= nums.length <= 10^5", "-10^4 <= nums[i] <= 10^4"},
			Examples:      []models.ProblemExample{{Input: "nums = [3,2,1,5,6,4], k = 2", Output: "5"}},
			DifficultyScore: 32, DifficultyLabel: "medium", PrimaryPattern: "heap", TimeComplexity: "O(n log k)", SpaceComplexity: "O(k)",
			Frequency: 0.85, Companies: []string{"Meta", "Amazon", "Google"},
			TopicLinks: []models.ProblemTopicLink{
				{TopicID: "priority_queue", Relevance: 1.0, IsPrimary: true, PatternUsed: "min-heap of size k", KeyInsight: "Maintain min-heap of k elements, top is kth largest"},
			},
			TagSlugs: []string{"array", "heap", "sorting", "multiple-approaches", "meta", "amazon"},
		},

		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
		// BACKTRACKING
		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

		{
			LeetcodeNumber: intPtr(78), Slug: "subsets", Title: "Subsets",
			Statement:     "Given an integer array nums of unique elements, return all possible subsets (the power set).",
			Constraints:   []string{"1 <= nums.length <= 10", "-10 <= nums[i] <= 10", "All elements are unique"},
			Examples:      []models.ProblemExample{{Input: "nums = [1,2,3]", Output: "[[],[1],[2],[1,2],[3],[1,3],[2,3],[1,2,3]]"}},
			DifficultyScore: 25, DifficultyLabel: "medium", PrimaryPattern: "backtracking", TimeComplexity: "O(n * 2^n)", SpaceComplexity: "O(n)",
			Frequency: 0.75, Companies: []string{"Amazon", "Meta"},
			TopicLinks: []models.ProblemTopicLink{
				{TopicID: "backtracking", Relevance: 1.0, IsPrimary: true, PatternUsed: "include/exclude pattern", KeyInsight: "At each element, choose to include or exclude it"},
			},
			TagSlugs: []string{"array", "backtracking", "bit-manipulation", "multiple-approaches"},
		},

		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
		// UNION-FIND
		// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

		{
			LeetcodeNumber: intPtr(547), Slug: "number-of-provinces", Title: "Number of Provinces",
			Statement:     "Given an n x n adjacency matrix isConnected where isConnected[i][j] = 1 means city i and j are directly connected, return the total number of provinces.",
			Constraints:   []string{"1 <= n <= 200", "isConnected[i][j] is 1 or 0"},
			Examples:      []models.ProblemExample{{Input: "isConnected = [[1,1,0],[1,1,0],[0,0,1]]", Output: "2"}},
			DifficultyScore: 28, DifficultyLabel: "medium", PrimaryPattern: "union_find", TimeComplexity: "O(n²α(n))", SpaceComplexity: "O(n)",
			Frequency: 0.65, Companies: []string{"Amazon", "Google"},
			TopicLinks: []models.ProblemTopicLink{
				{TopicID: "union_find", Relevance: 1.0, IsPrimary: true, PatternUsed: "union-find with path compression", KeyInsight: "Union connected cities, count remaining disjoint components"},
				{TopicID: "graph_dfs", Relevance: 0.7, IsPrimary: false, PatternUsed: "DFS alternative"},
			},
			TagSlugs: []string{"graph", "union-find", "dfs", "multiple-approaches"},
		},
	}
}
