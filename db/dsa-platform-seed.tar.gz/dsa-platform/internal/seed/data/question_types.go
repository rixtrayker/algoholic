package data

import "dsa-platform/pkg/models"

// SeedQuestionTypes returns the full question type taxonomy.
// Maps directly to the 10 categories from the taxonomy document.
func SeedQuestionTypes() []models.QuestionType {
	return []models.QuestionType{

		// ── Category 1: Complexity Analysis ───────────────
		{Slug: "code-to-complexity", CategoryCode: "1.1", Name: "Code-to-Complexity Identification", Description: "Show code snippet, identify time/space complexity", Format: models.FmtMultipleChoice, ParentCategory: "complexity_analysis", DifficultyDefault: "medium", EstimatedTimeSec: 120},
		{Slug: "complexity-comparison", CategoryCode: "1.2", Name: "Complexity Comparison Ranking", Description: "Rank multiple solutions by time/space complexity", Format: models.FmtRanking, ParentCategory: "complexity_analysis", DifficultyDefault: "medium", EstimatedTimeSec: 180},
		{Slug: "constraint-to-complexity", CategoryCode: "1.3", Name: "Constraint-to-Complexity Mapping", Description: "Given constraints (n ≤ 10⁹), determine required complexity", Format: models.FmtMultipleChoice, ParentCategory: "complexity_analysis", DifficultyDefault: "medium", EstimatedTimeSec: 150},
		{Slug: "hidden-complexity", CategoryCode: "1.4", Name: "Hidden Complexity Detection", Description: "Identify hidden costs in STL/library function calls", Format: models.FmtMultipleChoice, ParentCategory: "complexity_analysis", DifficultyDefault: "hard", EstimatedTimeSec: 180},

		// ── Category 2: Data Structure Selection ──────────
		{Slug: "requirements-to-ds", CategoryCode: "2.1", Name: "Requirements-to-DS Mapping", Description: "Given operation requirements, pick the right data structure", Format: models.FmtMultipleChoice, ParentCategory: "ds_selection", DifficultyDefault: "medium", EstimatedTimeSec: 120},
		{Slug: "ds-tradeoff", CategoryCode: "2.2", Name: "DS Trade-off Comparison", Description: "Compare two data structures for a given scenario", Format: models.FmtMultipleChoice, ParentCategory: "ds_selection", DifficultyDefault: "medium", EstimatedTimeSec: 150},
		{Slug: "stl-container-selection", CategoryCode: "2.3", Name: "STL Container Selection", Description: "Pick correct STL container for problem requirements", Format: models.FmtMultipleChoice, ParentCategory: "ds_selection", DifficultyDefault: "medium", EstimatedTimeSec: 120},
		{Slug: "custom-ds-design", CategoryCode: "2.4", Name: "Custom DS Design", Description: "When no single DS suffices, design a combination", Format: models.FmtOpenEnded, ParentCategory: "ds_selection", DifficultyDefault: "hard", EstimatedTimeSec: 300},

		// ── Category 3: Pattern Recognition ───────────────
		{Slug: "problem-to-pattern", CategoryCode: "3.1", Name: "Problem-to-Pattern Mapping", Description: "Read problem statement, identify which algorithmic pattern to use", Format: models.FmtMultipleChoice, ParentCategory: "pattern_recognition", DifficultyDefault: "medium", EstimatedTimeSec: 120},
		{Slug: "pattern-variation", CategoryCode: "3.2", Name: "Pattern Variation Recognition", Description: "Identify same pattern across seemingly different problems", Format: models.FmtMultipleChoice, ParentCategory: "pattern_recognition", DifficultyDefault: "medium", EstimatedTimeSec: 150},
		{Slug: "keyword-to-pattern", CategoryCode: "3.3", Name: "Keyword-to-Pattern Trigger", Description: "Map problem keywords to algorithmic patterns", Format: models.FmtMultipleChoice, ParentCategory: "pattern_recognition", DifficultyDefault: "easy", EstimatedTimeSec: 60},

		// ── Category 4: Edge Case & Overflow ──────────────
		{Slug: "edge-case-identification", CategoryCode: "4.1", Name: "Edge Case Identification", Description: "Identify edge cases that would break a given solution", Format: models.FmtMultipleChoice, ParentCategory: "edge_cases", DifficultyDefault: "medium", EstimatedTimeSec: 120},
		{Slug: "overflow-detection", CategoryCode: "4.2", Name: "Overflow Detection", Description: "Spot integer overflow risks in code", Format: models.FmtMultipleChoice, ParentCategory: "edge_cases", DifficultyDefault: "medium", EstimatedTimeSec: 120},
		{Slug: "base-case-testing", CategoryCode: "4.3", Name: "Base Case Testing", Description: "Verify correct base case handling in recursive/DP solutions", Format: models.FmtMultipleChoice, ParentCategory: "edge_cases", DifficultyDefault: "medium", EstimatedTimeSec: 120},
		{Slug: "boundary-condition", CategoryCode: "4.4", Name: "Boundary Condition Check", Description: "Check off-by-one errors and boundary handling", Format: models.FmtMultipleChoice, ParentCategory: "edge_cases", DifficultyDefault: "medium", EstimatedTimeSec: 90},

		// ── Category 5: Code Templates ────────────────────
		{Slug: "template-completion", CategoryCode: "5.1", Name: "Template Completion", Description: "Fill in missing parts of a standard algorithm template", Format: models.FmtFillBlank, ParentCategory: "code_templates", DifficultyDefault: "easy", EstimatedTimeSec: 120},
		{Slug: "template-adaptation", CategoryCode: "5.2", Name: "Template Adaptation", Description: "Modify a standard template for a variation of the problem", Format: models.FmtCode, ParentCategory: "code_templates", DifficultyDefault: "medium", EstimatedTimeSec: 300},
		{Slug: "template-identification", CategoryCode: "5.3", Name: "Template Identification", Description: "Given a problem, identify which template to start from", Format: models.FmtMultipleChoice, ParentCategory: "code_templates", DifficultyDefault: "easy", EstimatedTimeSec: 90},

		// ── Category 6: Implementation Correctness ────────
		{Slug: "return-value-semantics", CategoryCode: "6.1", Name: "Return Value Semantics", Description: "What does this function return for given input?", Format: models.FmtMultipleChoice, ParentCategory: "implementation", DifficultyDefault: "medium", EstimatedTimeSec: 120},
		{Slug: "loop-invariant", CategoryCode: "6.2", Name: "Loop Invariant Verification", Description: "Identify or verify loop invariant correctness", Format: models.FmtMultipleChoice, ParentCategory: "implementation", DifficultyDefault: "hard", EstimatedTimeSec: 180},
		{Slug: "dry-run-trace", CategoryCode: "6.3", Name: "Dry Run / Trace", Description: "Trace through code step by step for given input", Format: models.FmtMultipleChoice, ParentCategory: "implementation", DifficultyDefault: "medium", EstimatedTimeSec: 180},

		// ── Category 7: Bug Detection ─────────────────────
		{Slug: "find-the-bug", CategoryCode: "7.1", Name: "Find the Bug", Description: "Given buggy code, identify the bug", Format: models.FmtDebug, ParentCategory: "bug_detection", DifficultyDefault: "medium", EstimatedTimeSec: 180},
		{Slug: "fix-the-bug", CategoryCode: "7.2", Name: "Fix the Bug", Description: "Given buggy code, provide the fix", Format: models.FmtCode, ParentCategory: "bug_detection", DifficultyDefault: "medium", EstimatedTimeSec: 240},
		{Slug: "will-it-crash", CategoryCode: "7.3", Name: "Will It Crash?", Description: "Determine if code will crash/infinite-loop for given input", Format: models.FmtMultipleChoice, ParentCategory: "bug_detection", DifficultyDefault: "medium", EstimatedTimeSec: 120},

		// ── Category 8: Pseudocode ────────────────────────
		{Slug: "pseudocode-to-code", CategoryCode: "8.1", Name: "Pseudocode to Code", Description: "Convert pseudocode description to working code", Format: models.FmtCode, ParentCategory: "pseudocode", DifficultyDefault: "medium", EstimatedTimeSec: 300},
		{Slug: "code-to-pseudocode", CategoryCode: "8.2", Name: "Code to Pseudocode", Description: "Describe what code does in high-level pseudocode", Format: models.FmtOpenEnded, ParentCategory: "pseudocode", DifficultyDefault: "easy", EstimatedTimeSec: 180},

		// ── Category 9: Trade-off Analysis ────────────────
		{Slug: "time-space-tradeoff", CategoryCode: "9.1", Name: "Time-Space Trade-off", Description: "Analyze when to sacrifice space for time and vice versa", Format: models.FmtMultipleChoice, ParentCategory: "tradeoffs", DifficultyDefault: "medium", EstimatedTimeSec: 150},
		{Slug: "approach-comparison", CategoryCode: "9.2", Name: "Approach Comparison", Description: "Compare multiple valid approaches and pick the best for given constraints", Format: models.FmtMultipleChoice, ParentCategory: "tradeoffs", DifficultyDefault: "hard", EstimatedTimeSec: 240},

		// ── Category 10: Hybrid Multi-Skill ───────────────
		{Slug: "full-problem-analysis", CategoryCode: "10.1", Name: "Full Problem Analysis", Description: "Multi-part: pattern → complexity → DS → pseudocode → analysis", Format: models.FmtOpenEnded, ParentCategory: "hybrid", DifficultyDefault: "hard", EstimatedTimeSec: 600},
		{Slug: "optimization-challenge", CategoryCode: "10.2", Name: "Optimization Challenge", Description: "Start with brute force, progressively optimize through multiple stages", Format: models.FmtCode, ParentCategory: "hybrid", DifficultyDefault: "hard", EstimatedTimeSec: 900},
		{Slug: "design-implement", CategoryCode: "10.3", Name: "Design + Implementation", Description: "Design a data structure, justify choices, implement key methods", Format: models.FmtCode, ParentCategory: "hybrid", DifficultyDefault: "hard", EstimatedTimeSec: 900},
	}
}
