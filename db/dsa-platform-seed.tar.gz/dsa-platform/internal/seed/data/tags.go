package data

import "dsa-platform/pkg/models"

// SeedTags returns all tags organized by group.
func SeedTags() []models.Tag {
	return []models.Tag{

		// ── Pattern tags ──────────────────────────────────
		{Slug: "two-pointers", Name: "Two Pointers", TagGroup: "pattern", Color: "#3498DB"},
		{Slug: "sliding-window", Name: "Sliding Window", TagGroup: "pattern", Color: "#2ECC71"},
		{Slug: "binary-search", Name: "Binary Search", TagGroup: "pattern", Color: "#9B59B6"},
		{Slug: "bfs", Name: "BFS", TagGroup: "pattern", Color: "#1ABC9C"},
		{Slug: "dfs", Name: "DFS", TagGroup: "pattern", Color: "#16A085"},
		{Slug: "dp", Name: "Dynamic Programming", TagGroup: "pattern", Color: "#E67E22"},
		{Slug: "greedy", Name: "Greedy", TagGroup: "pattern", Color: "#F1C40F"},
		{Slug: "backtracking", Name: "Backtracking", TagGroup: "pattern", Color: "#E74C3C"},
		{Slug: "divide-conquer", Name: "Divide & Conquer", TagGroup: "pattern", Color: "#8E44AD"},
		{Slug: "monotonic-stack", Name: "Monotonic Stack", TagGroup: "pattern", Color: "#C0392B"},
		{Slug: "topological-sort", Name: "Topological Sort", TagGroup: "pattern", Color: "#2C3E50"},
		{Slug: "union-find", Name: "Union Find", TagGroup: "pattern", Color: "#34495E"},
		{Slug: "prefix-sum", Name: "Prefix Sum", TagGroup: "pattern", Color: "#27AE60"},
		{Slug: "bit-manipulation", Name: "Bit Manipulation", TagGroup: "pattern", Color: "#7F8C8D"},
		{Slug: "recursion", Name: "Recursion", TagGroup: "pattern", Color: "#D35400"},
		{Slug: "memoization", Name: "Memoization", TagGroup: "pattern", Color: "#E67E22"},
		{Slug: "tabulation", Name: "Tabulation", TagGroup: "pattern", Color: "#F39C12"},
		{Slug: "sorting", Name: "Sorting", TagGroup: "pattern", Color: "#2980B9"},
		{Slug: "hashing", Name: "Hashing", TagGroup: "pattern", Color: "#16A085"},

		// ── Data structure tags ───────────────────────────
		{Slug: "array", Name: "Array", TagGroup: "data_structure", Color: "#3498DB"},
		{Slug: "string", Name: "String", TagGroup: "data_structure", Color: "#2ECC71"},
		{Slug: "linked-list", Name: "Linked List", TagGroup: "data_structure", Color: "#9B59B6"},
		{Slug: "stack", Name: "Stack", TagGroup: "data_structure", Color: "#E74C3C"},
		{Slug: "queue", Name: "Queue", TagGroup: "data_structure", Color: "#1ABC9C"},
		{Slug: "hash-table", Name: "Hash Table", TagGroup: "data_structure", Color: "#16A085"},
		{Slug: "heap", Name: "Heap", TagGroup: "data_structure", Color: "#F1C40F"},
		{Slug: "binary-tree", Name: "Binary Tree", TagGroup: "data_structure", Color: "#27AE60"},
		{Slug: "bst", Name: "BST", TagGroup: "data_structure", Color: "#2C3E50"},
		{Slug: "graph", Name: "Graph", TagGroup: "data_structure", Color: "#8E44AD"},
		{Slug: "trie", Name: "Trie", TagGroup: "data_structure", Color: "#C0392B"},
		{Slug: "matrix", Name: "Matrix", TagGroup: "data_structure", Color: "#D35400"},
		{Slug: "segment-tree", Name: "Segment Tree", TagGroup: "data_structure", Color: "#2C3E50"},
		{Slug: "deque", Name: "Deque", TagGroup: "data_structure", Color: "#7F8C8D"},

		// ── Difficulty trait tags ─────────────────────────
		{Slug: "edge-case-heavy", Name: "Edge Case Heavy", TagGroup: "difficulty_trait", Color: "#E74C3C"},
		{Slug: "overflow-prone", Name: "Overflow Prone", TagGroup: "difficulty_trait", Color: "#C0392B"},
		{Slug: "off-by-one", Name: "Off-by-One Risk", TagGroup: "difficulty_trait", Color: "#E67E22"},
		{Slug: "tricky-base-case", Name: "Tricky Base Case", TagGroup: "difficulty_trait", Color: "#D35400"},
		{Slug: "requires-proof", Name: "Requires Proof", TagGroup: "difficulty_trait", Color: "#8E44AD"},
		{Slug: "multiple-approaches", Name: "Multiple Approaches", TagGroup: "difficulty_trait", Color: "#3498DB"},
		{Slug: "space-optimization", Name: "Space Optimizable", TagGroup: "difficulty_trait", Color: "#27AE60"},

		// ── Company tags ─────────────────────────────────
		{Slug: "google", Name: "Google", TagGroup: "company", Color: "#4285F4"},
		{Slug: "meta", Name: "Meta", TagGroup: "company", Color: "#1877F2"},
		{Slug: "amazon", Name: "Amazon", TagGroup: "company", Color: "#FF9900"},
		{Slug: "microsoft", Name: "Microsoft", TagGroup: "company", Color: "#00A4EF"},
		{Slug: "apple", Name: "Apple", TagGroup: "company", Color: "#A3AAAE"},
		{Slug: "netflix", Name: "Netflix", TagGroup: "company", Color: "#E50914"},
		{Slug: "uber", Name: "Uber", TagGroup: "company", Color: "#000000"},
		{Slug: "bloomberg", Name: "Bloomberg", TagGroup: "company", Color: "#2800D7"},

		// ── Technique tags ───────────────────────────────
		{Slug: "in-place", Name: "In-Place", TagGroup: "technique", Color: "#27AE60"},
		{Slug: "two-pass", Name: "Two Pass", TagGroup: "technique", Color: "#3498DB"},
		{Slug: "sentinel-node", Name: "Sentinel Node", TagGroup: "technique", Color: "#9B59B6"},
		{Slug: "dummy-head", Name: "Dummy Head", TagGroup: "technique", Color: "#8E44AD"},
		{Slug: "coordinate-compression", Name: "Coordinate Compression", TagGroup: "technique", Color: "#2C3E50"},
		{Slug: "sweep-line", Name: "Sweep Line", TagGroup: "technique", Color: "#16A085"},
		{Slug: "math", Name: "Math", TagGroup: "technique", Color: "#D35400"},
	}
}
