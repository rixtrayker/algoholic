package data

import "dsa-platform/pkg/models"

// SeedCategories returns all top-level categories for the DSA platform.
func SeedCategories() []models.Category {
	return []models.Category{
		{Slug: "arrays_strings", Name: "Arrays & Strings", Description: "Linear data structures, pointer techniques, sliding windows, prefix sums", Icon: "📊", Color: "#4A90D9", DisplayOrder: 1},
		{Slug: "dynamic_programming", Name: "Dynamic Programming", Description: "Overlapping subproblems, optimal substructure, memoization and tabulation", Icon: "🧩", Color: "#E67E22", DisplayOrder: 2},
		{Slug: "graphs_trees", Name: "Graphs & Trees", Description: "Graph traversals, shortest paths, tree algorithms, MST", Icon: "🌳", Color: "#27AE60", DisplayOrder: 3},
		{Slug: "sorting_searching", Name: "Sorting & Searching", Description: "Comparison sorts, binary search, search on answer space", Icon: "🔍", Color: "#8E44AD", DisplayOrder: 4},
		{Slug: "stacks_queues", Name: "Stacks & Queues", Description: "LIFO/FIFO, monotonic stacks/queues, deques, priority queues", Icon: "📚", Color: "#C0392B", DisplayOrder: 5},
		{Slug: "hash_tables", Name: "Hash Tables", Description: "Hashing, frequency counting, two-sum patterns, collision handling", Icon: "🗂️", Color: "#16A085", DisplayOrder: 6},
		{Slug: "greedy_backtracking", Name: "Greedy & Backtracking", Description: "Greedy choice property, constraint satisfaction, pruning strategies", Icon: "⚡", Color: "#F39C12", DisplayOrder: 7},
		{Slug: "advanced_ds", Name: "Advanced Data Structures", Description: "Segment trees, Fenwick trees, tries, union-find, sparse tables", Icon: "🏗️", Color: "#2C3E50", DisplayOrder: 8},
		{Slug: "bit_manipulation", Name: "Bit Manipulation", Description: "Bitwise operations, XOR tricks, bitmask DP, power of two checks", Icon: "🔢", Color: "#7F8C8D", DisplayOrder: 9},
		{Slug: "math_geometry", Name: "Math & Geometry", Description: "Number theory, combinatorics, modular arithmetic, computational geometry", Icon: "📐", Color: "#D35400", DisplayOrder: 10},
	}
}
