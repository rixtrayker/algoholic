package main

import (
	"context"
	"database/sql"
	"fmt"
	"log"
	"os"
	"strings"
	"time"

	"dsa-platform/internal/seed"

	_ "github.com/lib/pq"
)

func main() {
	dsn := os.Getenv("DATABASE_URL")
	if dsn == "" {
		dsn = "postgres://leetcode:leetcode123@localhost:5432/leetcode_training?sslmode=disable"
	}

	log.Println("🚀 DSA Platform — Database Seeder")
	log.Printf("   Connecting to: %s", maskDSN(dsn))

	db, err := sql.Open("postgres", dsn)
	if err != nil {
		log.Fatalf("❌ Failed to open DB: %v", err)
	}
	defer db.Close()

	db.SetMaxOpenConns(10)
	db.SetMaxIdleConns(5)
	db.SetConnMaxLifetime(5 * time.Minute)

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()

	if err := db.PingContext(ctx); err != nil {
		log.Fatalf("❌ DB not reachable: %v", err)
	}
	log.Println("   ✅ Connected to PostgreSQL")

	seeder := seed.New(ctx, db)
	if err := seeder.RunAll(); err != nil {
		log.Fatalf("❌ Seed failed: %v", err)
	}

	// Print summary
	printSummary(ctx, db)
}

func printSummary(ctx context.Context, db *sql.DB) {
	tables := []string{"categories", "topics", "tags", "problems", "question_types", "questions", "pitfalls", "problem_topics", "problem_tags"}
	fmt.Println("\n📊 Seed Summary:")
	fmt.Println(strings.Repeat("─", 40))
	for _, t := range tables {
		var count int
		db.QueryRowContext(ctx, fmt.Sprintf("SELECT COUNT(*) FROM %s", t)).Scan(&count)
		fmt.Printf("   %-20s %d rows\n", t, count)
	}
	fmt.Println(strings.Repeat("─", 40))
}

func maskDSN(dsn string) string {
	// Simple masking for log output
	if len(dsn) > 30 {
		return dsn[:20] + "***"
	}
	return "***"
}
